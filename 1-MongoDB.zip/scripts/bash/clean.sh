#!/bin/bash

rm -rf ./data 2>/dev/null