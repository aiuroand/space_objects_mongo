# First launch
	sudo make init
# Default launch
	sudo make run
# Default stop
	sudo make stop
# Clean saved information
	sudo make clean
# Run router console
	sudo make console